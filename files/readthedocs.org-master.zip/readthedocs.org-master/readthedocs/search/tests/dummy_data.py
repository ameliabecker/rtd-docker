PROJECT_DATA_FILES = {
    'pipeline': ['installation', 'signals'],
    'kuma': ['documentation', 'docker'],
    'docs': ['story', 'wiping'],
}

ALL_PROJECTS = PROJECT_DATA_FILES.keys()
