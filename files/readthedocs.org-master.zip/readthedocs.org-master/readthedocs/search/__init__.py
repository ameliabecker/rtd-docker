default_app_config = 'readthedocs.search.apps.SearchConfig'
