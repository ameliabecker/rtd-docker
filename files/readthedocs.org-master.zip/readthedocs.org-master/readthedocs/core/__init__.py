# -*- coding: utf-8 -*-

"""App initialization."""

default_app_config = 'readthedocs.core.apps.CoreAppConfig'
