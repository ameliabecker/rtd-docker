# -*- coding: utf-8 -*-

"""Project app config."""

from django.apps import AppConfig


class ProjectsConfig(AppConfig):
    name = 'readthedocs.projects'
