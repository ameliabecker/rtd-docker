# -*- coding: utf-8 -*-
default_app_config = 'readthedocs.projects.apps.ProjectsConfig'
