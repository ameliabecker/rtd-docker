# -*- coding: utf-8 -*-

"""Logic to parse and validate ``readthedocs.yaml`` file."""
from .config import *  # noqa
from .parser import *  # noqa
