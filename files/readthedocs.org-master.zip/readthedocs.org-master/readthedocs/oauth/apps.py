# -*- coding: utf-8 -*-

"""OAuth app config."""

from django.apps import AppConfig


class OAuthConfig(AppConfig):
    name = 'readthedocs.oauth'
