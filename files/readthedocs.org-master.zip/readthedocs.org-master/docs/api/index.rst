Public API
==========

This section of the documentation details the public API
usable to get details of projects, builds, versions and other details
from Read the Docs.



.. toctree::
    :maxdepth: 3

    v2
