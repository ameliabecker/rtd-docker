Design Documents
================

This is where we outline the design of major parts of our project.
Generally this is only available for features that have been build in the recent past,
but we hope to write more of them over time.

.. toctree::
   :maxdepth: 1
   :glob:

   *
